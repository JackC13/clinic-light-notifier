// 看診燈號 LINE 機器人（Cloudflare Worker，臺大醫院）
//   fetch     : 接收 LINE webhook，處理群組指令與按鈕
//   scheduled : 每分鐘檢查到期的追蹤，抓燈號、推播

import { parseCommand, HELP, NOTE_HELP, NOTE_CATEGORIES, AI_HELP } from "./commands.js";
import { verifySignature, reply, push, textMsg, quickPostback, quickText, getContent, imageMsg, quickCamera, quickCameraRoll, showLoading } from "./line.js";
import { aiProvider, chat, parseAiOutput, parseTaipeiTime, buildSystemPrompt, transcribe, toBase64 } from "./ai.js";
import {
  HOSPITALS, AMPM, hospitalName, currentAmpm, fetchTable, fetchDetail, diagnose, parseDetailUrl, detailUrl, baseUrl,
} from "./ntuh.js";
import { loadConfig, onReading, onFailure, onDetail, isExpired, title, keepIfWaiting, CHECKIN_NOTE } from "./monitor.js";
import { formatWhen } from "./when.js";
import { logHistory, historyReply, recentHistoryText } from "./history.js";

const MAX_ACTIVE_PER_CHAT = 10;
const MAX_PER_TICK = 30;
const PENDING_TTL = 10 * 60_000;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") return new Response("clinic-light-bot OK");
    const img = url.pathname.match(/^\/img\/([0-9a-f]{32}(?:_p)?)$/);
    if (request.method === "GET" && img) return serveImage(env, img[1]);
    if (request.method !== "POST" || url.pathname !== "/webhook") return new Response("Not found", { status: 404 });

    const body = await request.text();
    const ok = await verifySignature(env.LINE_CHANNEL_SECRET, body, request.headers.get("x-line-signature"));
    if (!ok) return new Response("Bad signature", { status: 401 });

    let events = [];
    try {
      events = JSON.parse(body).events ?? [];
    } catch {
      return new Response("Bad JSON", { status: 400 });
    }
    // 先回 200 給 LINE，指令在背景處理
    ctx.waitUntil(Promise.allSettled(events.map((e) => handleEvent(e, env, url.origin))));
    return new Response("OK");
  },

  async scheduled(_event, env, ctx) {
    ctx.waitUntil(tick(env, Date.now()));
  },
};

// ───────────────────────── 事件 ─────────────────────────

function allowedChats(env) {
  return String(env.ALLOWED_CHAT_IDS ?? "").split(",").map((s) => s.trim()).filter(Boolean);
}

async function handleEvent(event, env, origin) {
  const src = event.source ?? {};
  const chatId = src.groupId ?? src.roomId ?? src.userId;
  if (!chatId || !event.replyToken) return;

  let cmd = null;
  if (event.type === "message" && event.message?.type === "text") {
    const m = event.message;
    // @機器人：把提及的文字拿掉，整句交給 AI
    const selfMention = m.mention?.mentionees?.find((x) => x.isSelf);
    if (selfMention) {
      const stripped = m.mention.mentionees
        .filter((x) => x.isSelf)
        .sort((a, b) => b.index - a.index)
        .reduce((t, x) => t.slice(0, x.index) + t.slice(x.index + x.length), m.text);
      cmd = { cmd: "ai", text: stripped.trim() };
    } else {
      cmd = parseCommand(m.text);
      // 一對一聊天：不是指令的話都交給 AI
      if (!cmd && src.type === "user" && aiProvider(env)) cmd = { cmd: "ai", text: m.text.trim() };
    }
    // 回覆（引用）某則訊息時，把被引用的訊息帶給 AI（例如引用一張照片說「小弟 幫我看」）
    if (cmd?.cmd === "ai" && m.quotedMessageId) cmd.quotedMessageId = m.quotedMessageId;
  }
  else if (event.type === "message" && event.message?.type === "image") cmd = { cmd: "image", messageId: event.message.id };
  else if (event.type === "message" && event.message?.type === "audio") {
    cmd = { cmd: "audio", messageId: event.message.id, duration: event.message.duration ?? 0 };
  }
  else if (event.type === "postback") {
    try {
      cmd = { cmd: "postback", data: JSON.parse(event.postback.data) };
    } catch {
      return;
    }
  }
  if (!cmd) return;

  const allowed = allowedChats(env);
  if (allowed.length === 0) {
    if (cmd.cmd === "number" || cmd.cmd === "image" || cmd.cmd === "audio") return;
    return reply(env, event.replyToken,
      `🔒 尚未設定授權聊天室。\n這個聊天室的 ID：\n${chatId}\n請加到 ALLOWED_CHAT_IDS 後重新部署。`);
  }
  if (!allowed.includes(chatId)) return;

  const ctx = { env, origin, chatId, userId: src.userId ?? "", isDirect: src.type === "user", now: Date.now(), tables: new Map() };
  let out;
  try {
    out = await runCommand(cmd, ctx);
  } catch (e) {
    console.error(e);
    out = `❌ 發生錯誤：${e.message}`;
  }
  if (out) await reply(env, event.replyToken, out);
}

async function runCommand(cmd, ctx) {
  switch (cmd.cmd) {
    case "help": return textMsg(HELP, [quickText("☰ 選單", "選單"), quickText("📝 記事說明", "記事 說明")]);
    case "noteHelp": return textMsg(NOTE_HELP, [
      quickText("📝 看記事", "記事"), quickText("🛒 買什麼", "記事 買"), quickText("🎒 帶什麼", "記事 帶"),
      quickText("✈️ 出國", "記事 出國"), quickText("☰ 選單", "選單"),
    ]);
    case "menu": return menuCard(ctx);
    case "usage": return `❓ ${cmd.reason}\n\n輸入「說明」看完整用法`;
    case "list": return listReply(ctx);
    case "cancel": return cancel(cmd, ctx);
    case "lookup": return lookup(cmd, ctx);
    case "add": return addByDoctor(cmd, ctx);
    case "guide": return guide(cmd, ctx);
    case "addUrl": return addByUrl(cmd, ctx);
    case "number": return answerNumber(cmd.number, ctx);
    case "postback": return onPostback(cmd.data, ctx);
    case "notes": return notesReply(ctx, null, [], cmd.category ?? null);
    case "noteAdd": return noteAdd(cmd, ctx);
    case "noteDone": return noteDone(cmd, ctx);
    case "noteClear": return noteClear(cmd, ctx);
    case "noteEdit": return noteEdit(cmd, ctx);
    case "delete": return deleteByIds(cmd.ids, ctx);
    case "label": return setLabel(cmd, ctx);
    case "ai": return aiChat(cmd, ctx);
    case "remind": return remind(cmd, ctx);
    case "remindList": return remindList(ctx);
    case "remindCancel": return remindCancel(cmd.id, ctx);
    case "photoAsk": return photoAsk(cmd.id, ctx);
    case "photoShow": return photoShow(cmd.id, ctx);
    case "image": return onImage(cmd, ctx);
    case "audio": return onVoice(cmd, ctx);
    case "history": return historyReply(ctx, cmd);
    case "diagnose": {
      const hosp = cmd.hosp ?? "CH";
      const ampm = cmd.ampm ?? currentAmpm(ctx.now);
      const trace = await diagnose(ctx.env, hosp, ampm);
      return [`🩺 診斷：${hospitalName(hosp)} ${AMPM[ampm]}`, "", ...trace.map((l) => `・${l}`)].join("\n");
    }
  }
  return null;
}

// ───────────────────────── 查詢 ─────────────────────────

/** 同一次處理內，同院區同時段只抓一次 */
function getTable(ctx, hosp, ampm) {
  const key = `${hosp}|${ampm}`;
  if (!ctx.tables.has(key)) ctx.tables.set(key, fetchTable(ctx.env, hosp, ampm));
  return ctx.tables.get(key);
}

/** 同一次處理內，同一診的燈號頁只抓一次 */
function getDetail(ctx, hosp, sid) {
  const key = `detail|${hosp}|${sid}`;
  if (!ctx.tables.has(key)) ctx.tables.set(key, fetchDetail(ctx.env, hosp, sid));
  return ctx.tables.get(key);
}

/** 找某一診：先查院區列表；列表查不到（例如查詢頁暫時 520）時改用不需要 token 的個別燈號頁 */
async function findClinic(ctx, hosp, ampm, sid) {
  try {
    const table = await getTable(ctx, hosp, ampm);
    return table.clinics.find((x) => x.sid === sid) ?? null;
  } catch (e) {
    const d = await getDetail(ctx, hosp, sid).catch(() => null);
    if (!d) throw e;
    console.warn(`列表失敗（${e.message}），改用燈號頁`);
    return {
      sid, hosp, number: d.current, note: "", byCheckin: false, fromDetail: true,
      room: d.room.replace(/^\S+\s+/, "").replace(/\s+/g, ""), doctor: d.doctor || "（醫師）",
    };
  }
}

/** 加入追蹤時，從燈號頁判斷你目前的報到狀態 */
function initialCheckin(d, my) {
  const me = d?.statuses.find((s) => s.n === my);
  if (!me) return { state: null };
  if (me.status === "checkin" || me.status === "oncall") {
    const ahead = d.statuses.filter((s) => s.n !== my && (s.status === "checkin" || s.status === "oncall")).map((s) => s.n);
    return { state: "approx", ahead };
  }
  return { state: "no" };
}

function searchHospitals(env) {
  return String(env.SEARCH_HOSPITALS ?? "CH,T0").split(",").map((s) => s.trim()).filter(Boolean);
}

const normName = (s) => String(s).replace(/\(代\)|（代）|\s/g, "");

/** 用醫師名找門診。沒指定院區 / 時段時，查 SEARCH_HOSPITALS 的所有時段（目前時段優先） */
async function search(ctx, { hosp, ampm, doctor }) {
  const hosps = hosp ? [hosp] : searchHospitals(ctx.env);
  const cur = currentAmpm(ctx.now);
  const ampms = ampm ? [ampm] : [cur, ...[1, 2, 3].filter((p) => p !== cur)];
  const combos = hosps.flatMap((h) => ampms.map((p) => [h, p]));
  const settled = await Promise.allSettled(combos.map(([h, p]) => getTable(ctx, h, p)));

  const q = normName(doctor);
  const matches = [];
  const errors = [];
  settled.forEach((r, i) => {
    const [h, p] = combos[i];
    if (r.status === "rejected") return errors.push(`${hospitalName(h)}${AMPM[p]}：${r.reason.message}`);
    for (const c of r.value.clinics) if (normName(c.doctor).includes(q)) matches.push({ ...c, hosp: h, ampm: p });
  });
  return { matches, errors, hosps, ampms };
}

const where = (c) => `${hospitalName(c.hosp)} ${AMPM[c.ampm]} ${c.room}`;
const status = (c) => (c.number === null ? "尚未開始看診" : `目前 ${c.number} 號`) + (c.note ? `（${c.note}）` : "");
const pickLabel = (c) => `${hospitalName(c.hosp).slice(0, 2)}${AMPM[c.ampm]} ${c.room} ${c.doctor}`;

function notFound(doctor, { errors, hosps, ampms }) {
  const scope = `${hosps.map(hospitalName).join("、")}（${ampms.map((p) => AMPM[p]).join("、")}）`;
  const lines = [`🔍 今天在 ${scope} 找不到「${doctor}」的門診。`];
  if (errors.length) lines.push("", "⚠️ 部分查詢失敗：", ...errors);
  lines.push("", "可以指定院區，例如：追蹤 25 總院 醫師名", "或輸入「追蹤」用按鈕選");
  return lines.join("\n");
}

async function lookup(cmd, ctx) {
  const res = await search(ctx, cmd);
  if (!res.matches.length) return notFound(cmd.doctor, res);
  const lines = res.matches.map((c) => `${c.doctor}｜${where(c)}\n  ${status(c)}`);
  const quick = res.matches.map((c) =>
    quickPostback(`追蹤 ${pickLabel(c)}`, { a: "s", h: c.hosp, p: c.ampm, s: c.sid }, `追蹤 ${c.doctor} ${c.room}`));
  return textMsg(["🔎 目前燈號", "", ...lines].join("\n"), quick);
}

// ───────────────────────── 新增追蹤 ─────────────────────────

async function addByDoctor(cmd, ctx) {
  const res = await search(ctx, cmd);
  if (!res.matches.length) return notFound(cmd.doctor, res);

  if (res.matches.length === 1) {
    const c = res.matches[0];
    if (cmd.number) return addTracking(ctx, { hosp: c.hosp, ampm: c.ampm, sid: c.sid, number: cmd.number });
    return askNumber(ctx, c, null);
  }
  // 同一位醫師今天有好幾診：用按鈕選
  const quick = res.matches.map((c) =>
    quickPostback(pickLabel(c), { a: "s", h: c.hosp, p: c.ampm, s: c.sid, n: cmd.number }, `選擇 ${c.doctor} ${where(c)}`));
  const lines = res.matches.map((c) => `・${where(c)} ${c.doctor}｜${status(c)}`);
  return textMsg([`找到 ${res.matches.length} 診，請選擇：`, ...lines].join("\n"), quick);
}

async function addByUrl(cmd, ctx) {
  const info = parseDetailUrl(cmd.url);
  if (!info || info.host !== new URL(baseUrl(ctx.env)).hostname) {
    return "❌ 請貼臺大醫院的燈號頁網址（含 ServiceIDSE=…）";
  }
  const cur = currentAmpm(ctx.now);
  for (const p of [cur, ...[1, 2, 3].filter((x) => x !== cur)]) {
    let table;
    try {
      table = await getTable(ctx, info.hosp, p);
    } catch {
      continue;
    }
    const c = table.clinics.find((x) => x.sid === info.sid);
    if (!c) continue;
    const clinic = { ...c, hosp: info.hosp, ampm: p };
    if (cmd.number) return addTracking(ctx, { hosp: info.hosp, ampm: p, sid: info.sid, number: cmd.number, label: cmd.label });
    return askNumber(ctx, clinic, cmd.label);
  }
  return "❌ 今天的看診列表中找不到這一診（網址可能不是今天的）";
}

/** 按鈕流程：院區 → 時段 → 診 */
async function guide(cmd, ctx) {
  const n = cmd.number ?? undefined;
  if (!cmd.hosp) {
    const quick = HOSPITALS.map((h) => quickPostback(h.name, { a: "h", h: h.code, n }, h.name));
    return textMsg("🏥 請選擇院區\n（也可以直接輸入：追蹤 25 醫師名）", quick);
  }
  if (!cmd.ampm) {
    const cur = currentAmpm(ctx.now);
    const quick = [1, 2, 3].map((p) =>
      quickPostback(`${AMPM[p]}${p === cur ? "（現在）" : ""}`, { a: "p", h: cmd.hosp, p, n }, `${hospitalName(cmd.hosp)} ${AMPM[p]}`));
    return textMsg(`${hospitalName(cmd.hosp)}：請選擇時段`, quick);
  }
  const table = await getTable(ctx, cmd.hosp, cmd.ampm);
  if (!table.clinics.length) return `${hospitalName(cmd.hosp)} ${AMPM[cmd.ampm]} 目前查不到門診。`;
  return clinicsFlex(table.clinics, cmd.hosp, cmd.ampm, n);
}

function clinicsFlex(clinics, hosp, ampm, n) {
  const PER = 10;
  const list = clinics.slice(0, PER * 12); // carousel 最多 12 頁
  const pages = [];
  for (let i = 0; i < list.length; i += PER) pages.push(list.slice(i, i + PER));
  const head = `${hospitalName(hosp)} ${AMPM[ampm]}`;
  const bubbles = pages.map((page, i) => ({
    type: "bubble",
    size: "kilo",
    header: {
      type: "box", layout: "vertical", paddingBottom: "sm",
      contents: [
        { type: "text", text: head, weight: "bold", size: "md" },
        { type: "text", text: `第 ${i + 1}/${pages.length} 頁・右側為目前燈號・※ 依報到順序`, size: "xxs", color: "#888888", wrap: true },
      ],
    },
    body: {
      type: "box", layout: "vertical", spacing: "xs", paddingTop: "none",
      contents: page.map((c) => ({
        type: "button", style: "secondary", height: "sm",
        action: {
          type: "postback",
          label: `${c.room} ${c.doctor} ${c.number ?? "－"}${c.byCheckin ? " ※" : ""}`.slice(0, 40),
          data: JSON.stringify({ a: "s", h: hosp, p: ampm, s: c.sid, n }),
          displayText: `選擇 ${c.room} ${c.doctor}`,
        },
      })),
    },
  }));
  const more = clinics.length > list.length ? `（只列前 ${list.length} 診，其餘請用醫師名搜尋）` : "";
  return [
    { type: "flex", altText: `${head} 共 ${clinics.length} 診，請選擇`, contents: { type: "carousel", contents: bubbles } },
    `👆 ${head} 共 ${clinics.length} 診，左右滑動選擇${more}`,
  ];
}

async function onPostback(d, ctx) {
  if (d.a === "h") return guide({ hosp: d.h, number: d.n }, ctx);
  if (d.a === "p") return guide({ hosp: d.h, ampm: d.p, number: d.n }, ctx);
  if (d.a === "photo") return photoAsk(Number(d.id), ctx);
  if (d.a === "hint") return HINTS[d.k] ?? null;
  if (d.a === "undo" && Array.isArray(d.ids) && d.ids.length) {
    const ids = d.ids.map(Number).filter(Number.isInteger).slice(0, 20);
    const marks = ids.map(() => "?").join(",");
    const { results: rows } = await ctx.env.DB.prepare(`SELECT * FROM notes WHERE chat_id = ? AND id IN (${marks})`)
      .bind(ctx.chatId, ...ids).all();
    await deleteImages(ctx.env, rows);
    await logHistory(ctx, noteHist("undo", rows));
    const r = await ctx.env.DB.prepare(`DELETE FROM notes WHERE chat_id = ? AND id IN (${marks})`).bind(ctx.chatId, ...ids).run();
    return r.meta.changes ? "↩️ 已撤銷" : "已經刪除或完成了";
  }
  if (d.a === "s") {
    if (d.n) return addTracking(ctx, { hosp: d.h, ampm: d.p, sid: d.s, number: d.n });
    const c = await findClinic(ctx, d.h, d.p, d.s);
    if (!c) return "❌ 今天的列表中找不到這一診";
    return askNumber(ctx, { ...c, hosp: d.h, ampm: d.p }, null);
  }
  return null;
}

/** 選好診但還不知道號碼：記下來，等同一個人回覆號碼 */
async function askNumber(ctx, c, label) {
  await ctx.env.DB.prepare(
    `INSERT OR REPLACE INTO pending (chat_id, user_id, hosp, ampm, service_id, label, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).bind(ctx.chatId, ctx.userId, c.hosp, c.ampm, c.sid, label, ctx.now + PENDING_TTL).run();
  return `👨‍⚕️ ${c.doctor}｜${where(c)}\n${status(c)}\n\n請輸入你的號碼（例如 25）`;
}

async function answerNumber(number, ctx) {
  const p = await ctx.env.DB.prepare("SELECT * FROM pending WHERE chat_id = ? AND user_id = ?")
    .bind(ctx.chatId, ctx.userId).first();
  if (!p || p.expires_at < ctx.now) return null; // 沒有待填號碼：一般數字訊息不理會
  await ctx.env.DB.prepare("DELETE FROM pending WHERE chat_id = ? AND user_id = ?").bind(ctx.chatId, ctx.userId).run();
  if (number <= 0) return "號碼必須大於 0";
  return addTracking(ctx, { hosp: p.hosp, ampm: p.ampm, sid: p.service_id, number, label: p.label });
}

async function addTracking(ctx, { hosp, ampm, sid, number, label = null }) {
  const c = await findClinic(ctx, hosp, ampm, sid);
  if (!c) return "❌ 今天的列表中找不到這一診";
  const clinic = { ...c, hosp, ampm };

  const rows = await activeRows(ctx);
  if (rows.length >= MAX_ACTIVE_PER_CHAT) return `❌ 最多同時追蹤 ${MAX_ACTIVE_PER_CHAT} 筆，請先取消一些`;
  const dup = rows.find((r) => r.service_id === sid && r.my_number === number);
  if (dup) return `ℹ️ 已經在追蹤了：${title(dup)}，${number} 號`;
  // 依報到順序的診不照號碼叫，不用號碼大小擋
  if (!c.byCheckin && c.number !== null && c.number >= number) {
    return c.number === number
      ? `🔔 ${c.doctor}｜${where(clinic)} 目前燈號就是你的 ${number} 號，請直接到診間（不需要追蹤）`
      : `⚠️ ${c.doctor}｜${where(clinic)} 目前燈號 ${c.number} 已超過你的 ${number} 號，請盡速到診間報到（沒有加入追蹤）`;
  }

  let detail = null;
  try {
    detail = await getDetail(ctx, hosp, sid);
  } catch (e) {
    console.warn("燈號頁讀取失敗", e.message);
  }
  const ci = initialCheckin(detail, number);

  // 加入時的回覆已經告知剩幾號：已跨過的門檻視為通知過，避免下一分鐘重複推播
  const remaining = c.byCheckin
    ? (ci.state === "approx" ? ci.ahead.length : Infinity)
    : c.number === null ? Infinity : number - c.number;
  const sent = loadConfig(ctx.env).thresholds.filter((th) => remaining <= th).join(",");

  const res = await ctx.env.DB.prepare(
    `INSERT INTO trackings (chat_id, url, my_number, label, hosp, ampm, service_id, doctor, room,
       last_number, sent, by_checkin, checkin_state, ahead, ahead_left,
       fail_count, fail_alerted, drop_alerted, created_at, next_check_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?)`,
  ).bind(ctx.chatId, detailUrl(baseUrl(ctx.env), hosp, sid), number, label, hosp, ampm, sid, c.doctor, c.room,
    c.number, sent, c.byCheckin ? 1 : 0, ci.state, ci.ahead ? JSON.stringify(ci.ahead) : null,
    ci.ahead ? ci.ahead.length : null, ctx.now, ctx.now + 55_000).run();
  const row = { id: res.meta.last_row_id, doctor: c.doctor, room: c.room, hosp, ampm, label };
  await logHistory(ctx, [{ kind: "track", action: "add", ref_id: row.id, text: `${title(row)} ${number} 號` }]);

  const lines = [`✅ 已加入追蹤 ${title(row)}`, `你的號碼：${number}`];
  lines.push(c.number === null ? "目前尚未開始看診，開始後會通知"
    : c.byCheckin ? `目前燈號：${c.number}` : `目前燈號：${c.number}（還有 ${number - c.number} 號）`);
  if (ci.state === "no") lines.push(c.byCheckin ? "你目前：未報到（報到後開始計算前面還有幾位）" : "你目前：未報到");
  if (ci.state === "approx") {
    lines.push(c.byCheckin
      ? `你目前：已報到，前面最多 ${ci.ahead.length} 位（加入前就已報到，無法確定先後）`
      : "你目前：已報到");
  }
  if (c.byCheckin) lines.push("", "ℹ️ 此診依報到順序看診：會依「誰比你先報到」計算前面還有幾位，請盡早報到");
  const { results: bring } = await ctx.env.DB.prepare("SELECT text FROM notes WHERE chat_id = ? AND category = 'bring' ORDER BY id")
    .bind(ctx.chatId).all();
  if (bring.length) lines.push("", `🎒 記得帶：${bring.map((n) => n.text).join("、")}`);
  if (!label) lines.push("", `加備註：備註 ${row.id} 內容`);
  return lines.join("\n");
}

// ───────────────────────── 列表 / 取消 ─────────────────────────

async function activeRows(ctx) {
  const { results } = await ctx.env.DB.prepare("SELECT * FROM trackings WHERE chat_id = ? ORDER BY id").bind(ctx.chatId).all();
  return results;
}

function fmtTime(ms) {
  return new Date(ms).toLocaleTimeString("zh-TW", { timeZone: "Asia/Taipei", hour: "2-digit", minute: "2-digit", hour12: false });
}

async function listReply(ctx) {
  const rows = await activeRows(ctx);
  if (!rows.length) return "目前沒有追蹤中的看診。\n輸入「說明」看用法";
  const lines = [`📋 追蹤中 ${rows.length} 筆`];
  for (const r of rows) {
    const now = r.last_number === null ? "尚未開始看診" : `目前 ${r.last_number} 號`;
    let s;
    if (r.by_checkin) {
      s = r.checkin_state === "yes" || r.checkin_state === "approx"
        ? `${now}，已報到，前面${r.checkin_state === "approx" ? "最多" : "還有"} ${r.ahead_left ?? "?"} 位`
        : `${now}，未報到`;
    } else {
      s = r.last_number === null ? now : `${now}，剩 ${Math.max(r.my_number - r.last_number, 0)} 號`;
      if (r.checkin_state === "no") s += "，未報到";
    }
    const warn = (r.by_checkin ? "（依報到順序）" : "") + (r.fail_alerted ? "（⚠️ 讀取異常）" : "");
    lines.push("", title(r), `  你是 ${r.my_number} 號｜${s}${warn}｜${fmtTime(r.created_at)} 加入`);
  }
  const quick = rows.map((r) => quickText(`取消 #${r.id}`, `取消 ${r.id}`));
  return textMsg(lines.join("\n"), quick);
}

async function cancel(cmd, ctx) {
  const db = ctx.env.DB;
  if (cmd.all) {
    const { results: all } = await db.prepare("SELECT * FROM trackings WHERE chat_id = ?").bind(ctx.chatId).all();
    const r = await db.prepare("DELETE FROM trackings WHERE chat_id = ?").bind(ctx.chatId).run();
    await logHistory(ctx, all.map((t) => ({ kind: "track", action: "cancel", ref_id: t.id, text: `${title(t)} ${t.my_number} 號` })));
    return r.meta.changes ? `🗑 已取消全部 ${r.meta.changes} 筆追蹤` : "目前沒有追蹤中的看診";
  }
  const row = await db.prepare("SELECT * FROM trackings WHERE id = ? AND chat_id = ?").bind(cmd.id, ctx.chatId).first();
  if (!row) {
    const note = await db.prepare("SELECT text FROM notes WHERE id = ? AND chat_id = ?").bind(cmd.id, ctx.chatId).first();
    if (note) return textMsg(`追蹤裡沒有 #${cmd.id}。記事 #${cmd.id} 是「${note.text}」，要刪記事請用：刪除 ${cmd.id}`, [quickText(`🗑 刪除記事 #${cmd.id}`, `刪除 ${cmd.id}`)]);
    return `找不到 #${cmd.id}，輸入「列表」查看編號`;
  }
  await db.prepare("DELETE FROM trackings WHERE id = ?").bind(cmd.id).run();
  await logHistory(ctx, [{ kind: "track", action: "cancel", ref_id: row.id, text: `${title(row)} ${row.my_number} 號` }]);
  return `🗑 已取消 ${title(row)}，${row.my_number} 號`;
}

// ───────────────────────── 選單卡片 ─────────────────────────

const HINTS = {
  ai: textMsg("🤖 開頭叫「小弟」（或辦事小弟、小幫手、AI），或在群組 @機器人：\n　小弟 明天要帶什麼？\n　辦事小弟 幫我記週五要買牛奶和吐司\n　小弟 小孩發燒 38 度要注意什麼？"),
  lookup: textMsg("🔎 直接輸入「燈號 醫師名」\n例：燈號 王小明"),
  track: textMsg("🩺 直接輸入「追蹤 號碼 醫師名」最快\n例：追蹤 25 王小明\n\n或用按鈕一步一步選：", [quickText("用按鈕選", "追蹤")]),
  note: textMsg([
    "✏️ 直接打字就能記：",
    "　帶保鮮盒、買麵、買晚餐",
    "　記得帶健保卡",
    "　記得繳停車費",
    "　出國帶護照、轉接頭",
    "　明天帶月餅（前面加日期＝到時提醒）",
    "",
    "記下後可以按「📷 附圖」加照片",
    "完整用法：記事 說明",
  ].join("\n")),
};

// 配色：天空藍、白、項圈紅、鈴鐺黃
const THEME = {
  blue: "#0A9FE8",
  blueDark: "#0577B8",
  blueSoft: "#E3F4FD",
  red: "#E60033",
  yellow: "#FFD400",
  ink: "#12324A",
  muted: "#5B7A90",
};

async function menuCard(ctx) {
  const db = ctx.env.DB;
  const [t, n] = await Promise.all([
    db.prepare("SELECT COUNT(*) AS c FROM trackings WHERE chat_id = ?").bind(ctx.chatId).first(),
    db.prepare("SELECT COUNT(*) AS c FROM notes WHERE chat_id = ?").bind(ctx.chatId).first(),
  ]);

  const btn = (label, action, primary = false) => ({
    type: "button", height: "sm", flex: 1,
    style: primary ? "primary" : "secondary",
    color: primary ? THEME.blue : THEME.blueSoft,
    action: { label, ...action },
  });
  const msg = (label, text, primary) => btn(label, { type: "message", text }, primary);
  const hint = (label, k, primary) => btn(label, { type: "postback", data: JSON.stringify({ a: "hint", k }), displayText: label }, primary);
  const row = (...buttons) => ({ type: "box", layout: "horizontal", spacing: "sm", contents: buttons });
  const badge = (text) => ({
    type: "box", layout: "vertical", backgroundColor: THEME.yellow, cornerRadius: "xl",
    paddingStart: "md", paddingEnd: "md", paddingTop: "2px", paddingBottom: "2px", flex: 0,
    contents: [{ type: "text", text, size: "xxs", color: THEME.ink, weight: "bold" }],
  });
  const section = (title, badgeText) => ({
    type: "box", layout: "horizontal", margin: "lg", alignItems: "center",
    contents: [
      { type: "text", text: title, weight: "bold", size: "sm", color: THEME.ink, flex: 1 },
      badge(badgeText),
    ],
  });

  const bubble = {
    type: "bubble",
    size: "kilo",
    header: {
      type: "box", layout: "vertical", paddingAll: "none", backgroundColor: THEME.blue,
      contents: [
        {
          type: "box", layout: "horizontal", paddingAll: "md", alignItems: "center",
          contents: [
            {
              type: "box", layout: "vertical", flex: 1,
              contents: [
                { type: "text", text: "☰ 選單", weight: "bold", size: "lg", color: "#FFFFFF" },
                { type: "text", text: "點按鈕操作，也可以直接打字", size: "xxs", color: "#D6F0FF" },
              ],
            },
            // 黃色鈴鐺
            { type: "box", layout: "vertical", width: "18px", height: "18px", cornerRadius: "xxl",
              backgroundColor: THEME.yellow, borderColor: "#C9A400", borderWidth: "1px", contents: [] },
          ],
        },
        // 紅色項圈
        { type: "box", layout: "vertical", height: "6px", backgroundColor: THEME.red, contents: [] },
      ],
    },
    body: {
      type: "box", layout: "vertical", spacing: "sm", paddingTop: "sm",
      contents: [
        section("🩺 看診", t.c ? `追蹤中 ${t.c} 筆` : "沒有追蹤"),
        row(hint("追蹤看診", "track", true), msg("追蹤列表", "列表")),
        row(hint("查燈號", "lookup"), msg("說明", "說明")),
        { type: "separator", margin: "lg", color: THEME.blueSoft },
        section("📝 記事", n.c ? `${n.c} 筆` : "空的"),
        row(msg("看記事", "記事", true), hint("記一筆", "note")),
        row(msg("⏰ 提醒列表", "提醒列表"), msg("記事說明", "記事 說明")),
        row(msg("📜 歷史紀錄", "歷史")),
        ...(aiProvider(ctx.env) ? [row(hint("🤖 叫辦事小弟", "ai"))] : []),
      ],
    },
    styles: { header: { separator: false } },
  };
  return { type: "flex", altText: `☰ 選單（追蹤中 ${t.c} 筆、記事 ${n.c} 筆）`, contents: bubble };
}

// ───────────────────────── 記事本 / 備註 ─────────────────────────

const MAX_NOTES_PER_CHAT = 100;
const catOf = (key) => NOTE_CATEGORIES.find((c) => c.key === key) ?? NOTE_CATEGORIES.at(-1);
const noteLabel = (n) => `${catOf(n.category).icon} ${catOf(n.category).name}：${n.text}`;
const noteHist = (action, rows) => rows.map((n) => ({ kind: "note", action, ref_id: n.id, text: noteLabel(n) }));

async function notesReply(ctx, header = null, extraQuick = [], category = null) {
  const { results: all } = await ctx.env.DB.prepare("SELECT * FROM notes WHERE chat_id = ? ORDER BY id").bind(ctx.chatId).all();
  const only = category ? catOf(category) : null;
  const { results: rems } = await ctx.env.DB.prepare("SELECT due_at, note_ids FROM reminders WHERE chat_id = ? AND note_ids IS NOT NULL")
    .bind(ctx.chatId).all();
  const due = new Map();
  for (const r of rems) for (const id of r.note_ids.split(",")) if (!due.has(+id) || due.get(+id) > r.due_at) due.set(+id, r.due_at);
  const dueMark = (id) => (due.has(id) ? ` ⏰${formatWhen(due.get(id), ctx.now).replace(/^(?:今天|明天|後天) /, "").replace(/（.）/, " ")}` : "");
  const results = only ? all.filter((n) => n.category === only.key) : all;
  if (!results.length) {
    const empty = only ? `${only.icon} ${only.name}：目前沒有記事。` : "📝 記事本是空的。";
    const tip = only ? `新增：記 ${only.name} …` : "新增：記 買 尿布、牛奶　/　記 帶 健保卡　/　記 做 繳費";
    const others = only && all.length ? `（其他分類還有 ${all.length} 筆，輸入「記事」看全部）` : "";
    return [header, empty, others, tip].filter(Boolean).join("\n");
  }
  const lines = header ? [header, ""] : [];
  lines.push(only ? `${only.icon} ${only.name}（${results.length}）` : `📝 記事（${results.length}）`);
  for (const c of NOTE_CATEGORIES) {
    const items = results.filter((n) => n.category === c.key);
    if (!items.length) continue;
    if (!only) lines.push("", `${c.icon} ${c.name}`);
    lines.push(...items.map((n) => `${only ? "" : "  "}#${n.id} ${n.text}${n.image_key ? " 📷" : ""}${dueMark(n.id)}`));
  }
  lines.push("", "完成：完成 編號（可多筆）", "修改：改 編號 新內容");
  if (only && all.length > results.length) lines.push(`其他分類還有 ${all.length - results.length} 筆，輸入「記事」看全部`);
  const quick = [
    ...extraQuick,
    ...results.filter((n) => n.image_key).map((n) => quickText(`🖼 看圖 #${n.id} ${n.text}`, `看圖 ${n.id}`)),
    ...results.map((n) => quickText(`完成 #${n.id} ${n.text}`, `完成 ${n.id}`)),
  ];
  return textMsg(lines.join("\n"), quick);
}

async function noteAdd(cmd, ctx) {
  const db = ctx.env.DB;
  const entries = cmd.entries ?? cmd.items.map((text) => ({ category: cmd.category, text }));
  const count = (await db.prepare("SELECT COUNT(*) AS n FROM notes WHERE chat_id = ?").bind(ctx.chatId).first()).n;
  if (count + entries.length > MAX_NOTES_PER_CHAT) return `❌ 記事最多 ${MAX_NOTES_PER_CHAT} 筆，請先完成一些`;
  const results = await db.batch(entries.map((e) =>
    db.prepare("INSERT INTO notes (chat_id, category, text, created_at) VALUES (?, ?, ?, ?)").bind(ctx.chatId, e.category, e.text, ctx.now)));

  const ids = results.map((r) => r.meta.last_row_id);
  await logHistory(ctx, noteHist("add", entries.map((e, i) => ({ ...e, id: ids[i] }))));
  // 依分類整理：「🎒 帶：保鮮盒｜🛒 買：麵、晚餐」（提醒文字用，不含編號）
  const group = (fmt) => NOTE_CATEGORIES
    .map((c) => ({ c, items: entries.map((e, i) => ({ ...e, id: ids[i] })).filter((e) => e.category === c.key) }))
    .filter((x) => x.items.length)
    .map(({ c, items }) => `${c.icon} ${c.name}：${items.map(fmt).join("、")}`);
  const parts = group((e) => e.text);
  // 回覆附上編號，不用再查一次就能「完成 12」
  let head = `已記下 ${group((e) => `#${e.id} ${e.text}`).join("｜")}`;
  if (cmd.remindAt) {
    if (cmd.remindAt <= ctx.now + 30_000) {
      head += `\n（${formatWhen(cmd.remindAt, ctx.now)} 已經過了，沒有設提醒）`;
    } else {
      await db.prepare("INSERT INTO reminders (chat_id, text, due_at, note_ids, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)")
        .bind(ctx.chatId, parts.join("｜"), cmd.remindAt, ids.join(","), ctx.userId, ctx.now).run();
      head += `\n⏰ ${formatWhen(cmd.remindAt, ctx.now)} 提醒`;
    }
  }
  // 附圖按鈕：一次記多項時，每項各一個（快速回覆最多 13 個）
  const photoQuick = ids.slice(0, 8).map((id, i) =>
    quickPostback(ids.length > 1 ? `📷 ${entries[i].text}` : "📷 附圖", { a: "photo", id }, `附圖給「${entries[i].text}」`));
  if (!cmd.natural) return notesReply(ctx, head, photoQuick);

  // 口語觸發：簡短回覆，附「撤銷」與「完成」按鈕（快速回覆最多 13 個）
  const doneQuick = ids.slice(0, 4).map((id, i) => quickText(`✔️ 完成 #${id} ${entries[i].text}`, `完成 ${id}`));
  return textMsg(head, [
    quickPostback("↩️ 撤銷", { a: "undo", ids }, "撤銷"),
    ...doneQuick,
    ...photoQuick.slice(0, 4),
    quickText("📝 看記事", "記事"),
  ]);
}

async function noteDone(cmd, ctx) {
  const db = ctx.env.DB;
  const marks = cmd.ids.map(() => "?").join(",");
  const { results } = await db.prepare(`SELECT * FROM notes WHERE chat_id = ? AND id IN (${marks})`).bind(ctx.chatId, ...cmd.ids).all();
  if (!results.length) return `找不到 ${cmd.ids.map((i) => `#${i}`).join("、")}，輸入「記事」查看編號`;
  await deleteImages(ctx.env, results);
  await db.prepare(`DELETE FROM notes WHERE chat_id = ? AND id IN (${marks})`).bind(ctx.chatId, ...cmd.ids).run();
  await logHistory(ctx, noteHist("done", results));
  return notesReply(ctx, `✔️ 完成：${results.map((n) => n.text).join("、")}`);
}

/** 「刪除 30」：刪記事；編號只在追蹤裡才取消追蹤；兩邊都有就問 */
async function deleteByIds(ids, ctx) {
  const db = ctx.env.DB;
  const marks = ids.map(() => "?").join(",");
  const { results: notes } = await db.prepare(`SELECT * FROM notes WHERE chat_id = ? AND id IN (${marks})`).bind(ctx.chatId, ...ids).all();
  const { results: tracks } = await db.prepare(`SELECT * FROM trackings WHERE chat_id = ? AND id IN (${marks})`).bind(ctx.chatId, ...ids).all();
  const noteIds = new Set(notes.map((n) => n.id));
  const trackIds = new Set(tracks.map((t) => t.id));

  if (!notes.length && !tracks.length) return `找不到 ${ids.map((i) => `#${i}`).join("、")}，輸入「記事」或「列表」查看編號`;

  // 同一個編號同時是記事和追蹤：問清楚
  const both = ids.filter((i) => noteIds.has(i) && trackIds.has(i));
  if (both.length) {
    const i = both[0];
    const n = notes.find((x) => x.id === i), t = tracks.find((x) => x.id === i);
    return textMsg(`#${i} 同時有記事和追蹤，要刪哪一個？\n📝 記事：${n.text}\n🩺 追蹤：${title(t)} ${t.my_number} 號`, [
      quickText(`📝 刪記事 ${n.text}`, `完成 ${i}`),
      quickText(`🩺 取消追蹤 #${i}`, `取消 ${i}`),
    ]);
  }

  const lines = [];
  if (notes.length) {
    await deleteImages(ctx.env, notes);
    const nm = notes.map(() => "?").join(",");
    await db.prepare(`DELETE FROM notes WHERE chat_id = ? AND id IN (${nm})`).bind(ctx.chatId, ...noteIds).run();
    await logHistory(ctx, noteHist("delete", notes));
    lines.push(`🗑 已刪除記事：${notes.map((n) => `#${n.id} ${n.text}`).join("、")}`);
  }
  if (tracks.length) {
    const tm = tracks.map(() => "?").join(",");
    await db.prepare(`DELETE FROM trackings WHERE chat_id = ? AND id IN (${tm})`).bind(ctx.chatId, ...trackIds).run();
    await logHistory(ctx, tracks.map((t) => ({ kind: "track", action: "cancel", ref_id: t.id, text: `${title(t)} ${t.my_number} 號` })));
    lines.push(...tracks.map((t) => `🗑 已取消追蹤：${title(t)}，${t.my_number} 號`));
  }
  const missing = ids.filter((i) => !noteIds.has(i) && !trackIds.has(i));
  if (missing.length) lines.push(`（找不到 ${missing.map((i) => `#${i}`).join("、")}）`);
  if (!notes.length) return lines.join("\n");
  return notesReply(ctx, lines.join("\n"));
}

async function noteEdit(cmd, ctx) {
  const db = ctx.env.DB;
  const note = await db.prepare("SELECT * FROM notes WHERE id = ? AND chat_id = ?").bind(cmd.id, ctx.chatId).first();
  if (!note) return `找不到記事 #${cmd.id}，輸入「記事」查看編號`;
  const category = cmd.category ?? note.category;
  const text = cmd.text ?? note.text;
  if (category === note.category && text === note.text) return "內容一樣，沒有修改";
  await db.prepare("UPDATE notes SET category = ?, text = ? WHERE id = ?").bind(category, text, note.id).run();
  await logHistory(ctx, [{ kind: "note", action: "edit", ref_id: note.id, text: `${noteLabel(note)} → ${noteLabel({ category, text })}` }]);
  const from = catOf(note.category), to = catOf(category);
  const head = category === note.category
    ? `✏️ 已修改 #${note.id}：${note.text} → ${text}`
    : `✏️ 已修改 #${note.id}：${from.icon} ${from.name}「${note.text}」→ ${to.icon} ${to.name}「${text}」`;
  return notesReply(ctx, head, [], category);
}

async function noteClear(cmd, ctx) {
  const db = ctx.env.DB;
  const { results: rows } = cmd.category
    ? await db.prepare("SELECT * FROM notes WHERE chat_id = ? AND category = ?").bind(ctx.chatId, cmd.category).all()
    : await db.prepare("SELECT * FROM notes WHERE chat_id = ?").bind(ctx.chatId).all();
  await deleteImages(ctx.env, rows);
  await logHistory(ctx, noteHist("clear", rows));
  const r = cmd.category
    ? await db.prepare("DELETE FROM notes WHERE chat_id = ? AND category = ?").bind(ctx.chatId, cmd.category).run()
    : await db.prepare("DELETE FROM notes WHERE chat_id = ?").bind(ctx.chatId).run();
  const what = cmd.category ? `「${catOf(cmd.category).name}」` : "全部記事";
  return r.meta.changes ? `🗑 已清空${what}（${r.meta.changes} 筆）` : `${what}本來就是空的`;
}

// ── AI 小幫手 ──

const IMG_REF = /這張|那張|這個圖|圖片|照片|相片|截圖|單子|通知單|聯絡簿|藥袋|藥單|收據|發票|帳單|繳費單|看一下|看看|幫我看|讀一下|上面寫|裡面寫|寫什麼/;
const IMG_FOLLOW = /記下|記起來|記一下|幫我記|整理|提醒我|加到|存起來|都記|上面的/;
const LAST_MEDIA_TTL = 10 * 60_000;
const MAX_AI_IMAGE_BYTES = 5 * 1024 * 1024;

const MAX_VOICE_MS = 90_000;

/**
 * 語音訊息：用 Gemini 聽寫，再當成打字處理
 *   一對一：一律處理（不是指令就交給小弟）
 *   群組：VOICE_MODE=call（預設）要先叫「小弟…」才處理；all＝指令和口語記事也會處理；off＝不處理
 */
async function onVoice(cmd, ctx) {
  const env = ctx.env;
  const mode = String(env.VOICE_MODE ?? "call").toLowerCase();
  if (mode === "off") return null;
  const say = (t) => (ctx.isDirect ? t : null);   // 群組裡失敗不吵大家
  if (!env.GEMINI_API_KEY) return say("🎤 語音需要 Gemini 金鑰（GEMINI_API_KEY）");
  if (cmd.duration > MAX_VOICE_MS) return say("🎤 語音太長了，90 秒內比較好");
  const over = await aiQuota(ctx);
  if (over) return say(over);
  if (ctx.isDirect) await showLoading(env, ctx.chatId);

  let text;
  try {
    const a = await getContent(env, cmd.messageId);
    text = await transcribe(env, toBase64(a.body), "audio/m4a");
  } catch (e) {
    console.error("voice:", e);
    return say(`🎤 聽寫失敗：${e.message}`);
  }
  text = text.replace(/[。．.]+$/, "").trim();
  if (!text) return say("🎤 聽不清楚，再說一次？");

  let next = parseCommand(text, ctx.now);
  if (ctx.isDirect) next ??= { cmd: "ai", text };
  else if (mode !== "all" && next?.cmd !== "ai") return null;   // 群組：沒叫小弟就當沒聽到
  if (!next || next.cmd === "audio" || next.cmd === "number") return null;
  if (next.cmd === "ai") next.skipQuota = true;                    // 聽寫已經算過一次

  const out = await runCommand(next, ctx);
  const rest = out == null ? [] : Array.isArray(out) ? out : [out];
  return [`🎤「${text}」`, ...rest].slice(0, 5);
}

/** 每日 AI 次數上限，避免誤觸燒錢；超過回傳提示文字 */
async function aiQuota(ctx) {
  const db = ctx.env.DB;
  const limit = parseInt(ctx.env.AI_DAILY_LIMIT ?? "200", 10);
  const day = new Date(ctx.now + 8 * 3600_000).toISOString().slice(0, 10);
  const key = `ai_count:${ctx.chatId}:${day}`;
  const used = parseInt((await db.prepare("SELECT value FROM kv WHERE key = ?").bind(key).first())?.value ?? "0", 10);
  if (used >= limit) return `🤖 今天已經叫我 ${used} 次了，達到上限（AI_DAILY_LIMIT=${limit}），明天再來吧`;
  await db.prepare("INSERT OR REPLACE INTO kv (key, value, updated_at) VALUES (?, ?, ?)").bind(key, String(used + 1), ctx.now).run();
  return null;
}

const AI_HISTORY_TURNS = 8;              // 保留最近幾則（問＋答）
const AI_HISTORY_TTL = 3 * 3600_000;     // 超過 3 小時的對話不帶入

async function aiChat(cmd, ctx) {
  const env = ctx.env, db = env.DB;
  if (!aiProvider(env)) {
    return "🤖 AI 小幫手還沒設定金鑰。\n請在 worker 資料夾執行：\nnpx wrangler secret put ANTHROPIC_API_KEY\n（或 GEMINI_API_KEY）";
  }
  // 要給 AI 看的照片：引用（回覆）的那張，或這個人 10 分鐘內傳的最後一張（句子有提到「這張 / 單子…」時）
  // 要給 AI 看的照片：
  //   1. 引用（回覆）的那則
  //   2. 句子提到「這張 / 通知單…」：群組裡 10 分鐘內最後一張照片（誰傳的都算）
  //   3. 接著剛才看過的照片說「幫我記下來 / 整理一下」：同一張再看一次
  let imageId = cmd.quotedMessageId ?? null;
  if (!imageId && cmd.text && IMG_REF.test(cmd.text)) {
    const m = await db.prepare("SELECT message_id FROM last_media WHERE chat_id = ? AND created_at > ? ORDER BY created_at DESC LIMIT 1")
      .bind(ctx.chatId, ctx.now - LAST_MEDIA_TTL).first();
    imageId = m?.message_id ?? null;
  }
  const seenKey = `ai_img:${ctx.chatId}`;
  if (!imageId && cmd.text && IMG_FOLLOW.test(cmd.text)) {
    const seen = await db.prepare("SELECT value FROM kv WHERE key = ? AND updated_at > ?").bind(seenKey, ctx.now - LAST_MEDIA_TTL).first();
    imageId = seen?.value ?? null;
  }
  if (!cmd.text && imageId) cmd = { ...cmd, text: "幫我看這張" };
  if (!cmd.text) return textMsg(`${AI_HELP}\n\n可以問：\n・明天要帶什麼？\n・幫我記週五要買牛奶和吐司\n・（先傳照片）小弟 幫我看這張通知單\n・小孩發燒 38 度要注意什麼？`);

  if (!cmd.skipQuota) {
    const over = await aiQuota(ctx);
    if (over) return over;
  }

  if (ctx.chatId.startsWith("U")) await showLoading(env, ctx.chatId);

  const images = [];
  if (imageId) {
    try {
      const img = await getContent(env, imageId);
      if (img.body.byteLength > MAX_AI_IMAGE_BYTES) return "🤖 這張圖太大了（上限 5MB），截圖或壓小一點再傳";
      images.push({ mime: /png|gif|webp/.test(img.type) ? img.type : "image/jpeg", data: toBase64(img.body) });
      await db.prepare("INSERT OR REPLACE INTO kv (key, value, updated_at) VALUES (?, ?, ?)").bind(seenKey, imageId, ctx.now).run();
    } catch (e) {
      console.warn("讀取照片失敗", e.message);
      // 引用的是文字訊息就沒有圖可以拿，照常回答；主動說「這張」卻拿不到才提示
      if (!cmd.quotedMessageId) return "🤖 那張照片我拿不到了（太久以前或已刪除），再傳一次吧";
    }
  }

  // 給 AI 的背景資料
  const [{ results: notes }, { results: rems }, { results: tracks }, { results: hist }] = await Promise.all([
    db.prepare("SELECT id, category, text FROM notes WHERE chat_id = ? ORDER BY id").bind(ctx.chatId).all(),
    db.prepare("SELECT id, text, due_at, note_ids FROM reminders WHERE chat_id = ? ORDER BY due_at LIMIT 20").bind(ctx.chatId).all(),
    db.prepare("SELECT * FROM trackings WHERE chat_id = ? ORDER BY id").bind(ctx.chatId).all(),
    db.prepare("SELECT role, content FROM ai_history WHERE chat_id = ? AND created_at > ? ORDER BY id DESC LIMIT ?")
      .bind(ctx.chatId, ctx.now - AI_HISTORY_TTL, AI_HISTORY_TURNS).all(),
  ]);
  const system = buildSystemPrompt({
    nowText: formatWhen(ctx.now, ctx.now).replace(/^今天 /, "") + `（${new Date(ctx.now + 8 * 3600_000).getUTCFullYear()} 年）`,
    notes: notes.map((n) => `#${n.id} ${catOf(n.category).name}：${n.text}`).join("；"),
    reminders: rems.map((r) => `#${r.id} ${formatWhen(r.due_at, ctx.now)} ${r.text}`).join("；"),
    trackings: tracks.map((t) => `${title(t)} ${t.my_number} 號，目前 ${t.last_number ?? "未開始"}`).join("；"),
    history: await recentHistoryText(ctx),
  });
  const messages = [...hist.reverse(), { role: "user", content: cmd.text.slice(0, 2000) }];
  // Claude 要求第一則是 user
  while (messages.length && messages[0].role !== "user") messages.shift();

  let out;
  try {
    out = parseAiOutput(await chat(env, system, messages, images));
  } catch (e) {
    console.error("AI:", e);
    return `🤖 AI 暫時無法回應：${e.name === "TimeoutError" ? "等太久了，請再試一次" : e.message}`;
  }

  // 執行 AI 要求的動作（只有新增記事 / 提醒）
  const done = [], noteIds = [], quick = [];
  for (const a of out.actions) {
    try {
      if (a?.type === "note" && a.text) {
        const category = NOTE_CATEGORIES.some((c) => c.key === a.category) ? a.category : "other";
        const text = String(a.text).slice(0, 30);
        const r = await db.prepare("INSERT INTO notes (chat_id, category, text, created_at) VALUES (?, ?, ?, ?)")
          .bind(ctx.chatId, category, text, ctx.now).run();
        const id = r.meta.last_row_id;
        noteIds.push(id);
        await logHistory(ctx, noteHist("add", [{ id, category, text }]));
        let line = `📝 ${catOf(category).icon} ${catOf(category).name}：${text}（#${id}）`;
        const at = parseTaipeiTime(a.at);
        if (at && at > ctx.now + 30_000) {
          await db.prepare("INSERT INTO reminders (chat_id, text, due_at, note_ids, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)")
            .bind(ctx.chatId, `${catOf(category).icon} ${catOf(category).name}：${text}`, at, String(id), ctx.userId, ctx.now).run();
          line += ` ⏰ ${formatWhen(at, ctx.now)}`;
        }
        done.push(line);
      } else if (a?.type === "remind" && a.text) {
        const at = parseTaipeiTime(a.at);
        if (!at || at <= ctx.now + 30_000) continue;
        const text = String(a.text).slice(0, 60);
        const r = await db.prepare("INSERT INTO reminders (chat_id, text, due_at, note_ids, created_by, created_at) VALUES (?, ?, ?, NULL, ?, ?)")
          .bind(ctx.chatId, text, at, ctx.userId, ctx.now).run();
        done.push(`⏰ ${formatWhen(at, ctx.now)}：${text}（提醒 #${r.meta.last_row_id}）`);
        quick.push(quickText(`取消提醒 #${r.meta.last_row_id}`, `取消提醒 ${r.meta.last_row_id}`));
      }
    } catch (e) {
      console.error("AI action:", e);
    }
  }
  if (noteIds.length) quick.unshift(quickPostback("↩️ 撤銷記事", { a: "undo", ids: noteIds }, "撤銷"));

  const replyText = out.reply || (done.length ? "好的！" : "🤖 （沒有回應）");
  await db.batch([
    db.prepare("INSERT INTO ai_history (chat_id, role, content, created_at) VALUES (?, 'user', ?, ?)")
      .bind(ctx.chatId, (images.length ? "（附了一張照片）" : "") + cmd.text.slice(0, 2000), ctx.now),
    db.prepare("INSERT INTO ai_history (chat_id, role, content, created_at) VALUES (?, 'assistant', ?, ?)").bind(ctx.chatId, replyText.slice(0, 2000), ctx.now + 1),
    db.prepare("DELETE FROM ai_history WHERE created_at < ?").bind(ctx.now - AI_HISTORY_TTL),
  ]);

  const text = done.length ? `${replyText}\n\n${done.join("\n")}` : replyText;
  return textMsg(`🤖 ${text}`, quick);
}

// ── 提醒 ──

const MAX_REMINDERS_PER_CHAT = 50;
const MAX_REMIND_AHEAD = 400 * 86400_000;

async function remind(cmd, ctx) {
  const db = ctx.env.DB;
  if (cmd.at <= ctx.now + 30_000) {
    return cmd.hasTime
      ? `❌ ${formatWhen(cmd.at, ctx.now)} 已經過了`
      : `❌ ${formatWhen(cmd.at, ctx.now)} 已經過了，請加上時間（例：提醒 今天 18:00 ${cmd.text}）`;
  }
  if (cmd.at > ctx.now + MAX_REMIND_AHEAD) return "❌ 最多只能設一年內的提醒";
  const n = (await db.prepare("SELECT COUNT(*) AS n FROM reminders WHERE chat_id = ?").bind(ctx.chatId).first()).n;
  if (n >= MAX_REMINDERS_PER_CHAT) return `❌ 提醒最多 ${MAX_REMINDERS_PER_CHAT} 筆，請先取消一些`;
  const r = await db.prepare("INSERT INTO reminders (chat_id, text, due_at, note_ids, created_by, created_at) VALUES (?, ?, ?, NULL, ?, ?)")
    .bind(ctx.chatId, cmd.text, cmd.at, ctx.userId, ctx.now).run();
  const id = r.meta.last_row_id;
  return textMsg(`⏰ 好的，${formatWhen(cmd.at, ctx.now)} 提醒：${cmd.text}`, [
    quickText("↩️ 取消這個提醒", `取消提醒 ${id}`),
    quickText("⏰ 提醒列表", "提醒列表"),
  ]);
}

async function remindList(ctx) {
  const { results } = await ctx.env.DB.prepare("SELECT * FROM reminders WHERE chat_id = ? ORDER BY due_at LIMIT 30")
    .bind(ctx.chatId).all();
  if (!results.length) return textMsg("⏰ 目前沒有提醒。\n新增：提醒 明天 8點 帶傘　/　明天帶月餅（記事＋提醒）");
  const lines = [`⏰ 提醒（${results.length}）`, ""];
  for (const r of results) {
    if (r.note_ids) r.text = (await noteSummary(ctx.env, r.chat_id, r.note_ids)) ?? "（記事都完成了，不會提醒）";
    lines.push(`#${r.id} ${formatWhen(r.due_at, ctx.now)}　${r.note_ids ? "📝 " : ""}${r.text}`);
  }
  lines.push("", "取消：取消提醒 編號");
  return textMsg(lines.join("\n"), results.slice(0, 13).map((r) => quickText(`取消 #${r.id} ${r.text}`, `取消提醒 ${r.id}`)));
}

async function remindCancel(id, ctx) {
  const db = ctx.env.DB;
  const r = await db.prepare("SELECT * FROM reminders WHERE id = ? AND chat_id = ?").bind(id, ctx.chatId).first();
  if (!r) return `找不到提醒 #${id}，輸入「提醒列表」查看編號`;
  await db.prepare("DELETE FROM reminders WHERE id = ?").bind(id).run();
  return `🗑 已取消提醒：${formatWhen(r.due_at, ctx.now)} ${r.text}${r.note_ids ? "\n（記事還在，要刪記事請用「完成」）" : ""}`;
}

/** 連結的記事（還沒完成的）整理成「🎒 帶：月餅、餅乾」；都完成了回傳 null */
async function noteSummary(env, chatId, noteIds) {
  const ids = String(noteIds).split(",").map(Number).filter(Number.isInteger);
  if (!ids.length) return null;
  const marks = ids.map(() => "?").join(",");
  const { results: notes } = await env.DB.prepare(`SELECT category, text FROM notes WHERE chat_id = ? AND id IN (${marks}) ORDER BY id`)
    .bind(chatId, ...ids).all();
  if (!notes.length) return null;
  return NOTE_CATEGORIES
    .map((c) => ({ c, t: notes.filter((n) => n.category === c.key).map((n) => n.text) }))
    .filter((x) => x.t.length)
    .map(({ c, t }) => `${c.icon} ${c.name}：${t.join("、")}`)
    .join("｜");
}

/** 到期的提醒 → { chatId: [訊息] }；連結的記事都完成了就不提醒 */
async function dueReminders(env, now) {
  const { results } = await env.DB.prepare("SELECT * FROM reminders WHERE due_at <= ? ORDER BY due_at LIMIT 50").bind(now).all();
  const out = new Map();
  if (!results.length) return out;
  for (const r of results) {
    let text = r.text;
    if (r.note_ids) {
      text = await noteSummary(env, r.chat_id, r.note_ids);
      if (!text) continue;
    }
    out.set(r.chat_id, [...(out.get(r.chat_id) ?? []), `⏰ 提醒：${text}`]);
  }
  const marks = results.map(() => "?").join(",");
  await env.DB.prepare(`DELETE FROM reminders WHERE id IN (${marks})`).bind(...results.map((r) => r.id)).run();
  return out;
}

// ── 記事附圖 ──

const PHOTO_TTL = 5 * 60_000;
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;

async function photoAsk(id, ctx) {
  const note = await ctx.env.DB.prepare("SELECT * FROM notes WHERE id = ? AND chat_id = ?").bind(id, ctx.chatId).first();
  if (!note) return `找不到記事 #${id}，輸入「記事」查看編號`;
  if (!ctx.env.IMAGES) return "❌ 附圖功能尚未設定（wrangler.toml 缺少 IMAGES 的 KV 設定）";
  await ctx.env.DB.prepare("INSERT OR REPLACE INTO pending_photo (chat_id, user_id, note_id, expires_at) VALUES (?, ?, ?, ?)")
    .bind(ctx.chatId, ctx.userId, id, ctx.now + PHOTO_TTL).run();
  return textMsg(`📷 請在 5 分鐘內傳一張照片給「${note.text}」`, [quickCamera(), quickCameraRoll()]);
}

async function onImage(cmd, ctx) {
  const db = ctx.env.DB;
  const p = await db.prepare("SELECT * FROM pending_photo WHERE chat_id = ? AND user_id = ?").bind(ctx.chatId, ctx.userId).first();
  if (!p || p.expires_at < ctx.now) {
    // 一般照片：不回應，只記下編號，之後「小弟 幫我看這張」用得到
    await db.prepare("INSERT OR REPLACE INTO last_media (chat_id, user_id, message_id, created_at) VALUES (?, ?, ?, ?)")
      .bind(ctx.chatId, ctx.userId, cmd.messageId, ctx.now).run();
    return null;
  }
  await db.prepare("DELETE FROM pending_photo WHERE chat_id = ? AND user_id = ?").bind(ctx.chatId, ctx.userId).run();
  const note = await db.prepare("SELECT * FROM notes WHERE id = ? AND chat_id = ?").bind(p.note_id, ctx.chatId).first();
  if (!note) return "這筆記事已經不在了";

  const orig = await getContent(ctx.env, cmd.messageId);
  if (orig.body.byteLength > MAX_IMAGE_BYTES) return "❌ 圖片太大（上限 10MB）";
  let prev = orig;
  try {
    prev = await getContent(ctx.env, cmd.messageId, true);
  } catch {
    // 沒有預覽圖就用原圖
  }
  const key = crypto.randomUUID().replace(/-/g, "");
  await ctx.env.IMAGES.put(`img:${key}`, orig.body, { metadata: { type: orig.type } });
  await ctx.env.IMAGES.put(`img:${key}_p`, prev.body, { metadata: { type: prev.type } });
  if (note.image_key) await deleteImages(ctx.env, [note]);
  await db.prepare("UPDATE notes SET image_key = ? WHERE id = ?").bind(key, note.id).run();
  return textMsg(`📷 已附圖：#${note.id} ${note.text}`, [quickText("🖼 看圖", `看圖 ${note.id}`), quickText("📝 看記事", "記事")]);
}

async function photoShow(id, ctx) {
  const note = await ctx.env.DB.prepare("SELECT * FROM notes WHERE id = ? AND chat_id = ?").bind(id, ctx.chatId).first();
  if (!note) return `找不到記事 #${id}`;
  if (!note.image_key) return textMsg(`#${id} ${note.text} 還沒有附圖`, [quickPostback("📷 附圖", { a: "photo", id }, `附圖給「${note.text}」`)]);
  return [
    `🖼 #${note.id} ${note.text}`,
    imageMsg(`${ctx.origin}/img/${note.image_key}`, `${ctx.origin}/img/${note.image_key}_p`),
  ];
}

async function deleteImages(env, rows) {
  if (!env.IMAGES) return;
  await Promise.allSettled(rows.filter((r) => r.image_key).flatMap((r) =>
    [env.IMAGES.delete(`img:${r.image_key}`), env.IMAGES.delete(`img:${r.image_key}_p`)]));
}

async function serveImage(env, key) {
  if (!env.IMAGES) return new Response("Not found", { status: 404 });
  const { value, metadata } = await env.IMAGES.getWithMetadata(`img:${key}`, { type: "arrayBuffer" });
  if (!value) return new Response("Not found", { status: 404 });
  return new Response(value, {
    headers: { "Content-Type": metadata?.type ?? "image/jpeg", "Cache-Control": "private, max-age=86400" },
  });
}

async function setLabel(cmd, ctx) {
  const row = await ctx.env.DB.prepare("SELECT * FROM trackings WHERE id = ? AND chat_id = ?").bind(cmd.id, ctx.chatId).first();
  if (!row) return `找不到追蹤 #${cmd.id}，輸入「列表」查看編號`;
  await ctx.env.DB.prepare("UPDATE trackings SET label = ? WHERE id = ?").bind(cmd.text, cmd.id).run();
  const updated = { ...row, label: cmd.text };
  return cmd.text ? `📝 已加上備註：${title(updated)}\n之後的通知都會顯示這段備註` : `已清除 #${cmd.id} 的備註`;
}

// ───────────────────────── 排程 ─────────────────────────

export async function tick(env, now) {
  const cfg = loadConfig(env);
  await env.DB.prepare("DELETE FROM pending WHERE expires_at < ?").bind(now).run();
  await env.DB.prepare("DELETE FROM pending_photo WHERE expires_at < ?").bind(now).run();
  // 每小時清一次舊資料：歷史保留 1 年、照片編號保留 1 天
  if (now % 3_600_000 < 60_000) {
    await env.DB.batch([
      env.DB.prepare("DELETE FROM history WHERE created_at < ?").bind(now - 365 * 86400_000),
      env.DB.prepare("DELETE FROM last_media WHERE created_at < ?").bind(now - 86400_000),
    ]).catch((e) => console.error("cleanup:", e));
  }

  // 到期的提醒
  let byChat = new Map();
  try {
    byChat = await dueReminders(env, now);
  } catch (e) {
    console.error("reminders:", e);
  }

  const { results } = await env.DB.prepare(
    "SELECT * FROM trackings WHERE next_check_at <= ? ORDER BY next_check_at LIMIT ?",
  ).bind(now, MAX_PER_TICK).all();

  // 同院區同時段只抓一次列表
  const ctx = { env, now, tables: new Map() };
  const settled = await Promise.allSettled(results.map((row) => checkOne(row, cfg, ctx)));

  // 同一個群組在同一分鐘的通知合併成一則推播，節省額度
  settled.forEach((s, i) => {
    if (s.status === "rejected") return console.error(`tracking #${results[i].id}:`, s.reason);
    if (!s.value.length) return;
    const chat = results[i].chat_id;
    byChat.set(chat, [...(byChat.get(chat) ?? []), ...s.value]);
  });
  // 快輪到時（剩 5 以內、預計叫號、輪到了），附上「帶」的記事
  for (const [chat, msgs] of byChat) {
    if (!msgs.some((m) => /🟠|🔴|預計叫號|輪到了/.test(m))) continue;
    const { results: bring } = await env.DB.prepare("SELECT text FROM notes WHERE chat_id = ? AND category = 'bring' ORDER BY id")
      .bind(chat).all();
    if (bring.length) msgs.push(`🎒 記得帶：${bring.map((n) => n.text).join("、")}`);
  }
  await Promise.allSettled([...byChat].map(([chat, msgs]) => push(env, chat, msgs)));
}

const merge = (a, b) => ({ ...a, ...b, update: { ...a.update, ...b.update }, messages: [...a.messages, ...b.messages] });

/** 依列表 + 個別燈號頁判斷一筆追蹤 */
async function evaluate(row, c, cfg, ctx) {
  let d = null;
  try {
    d = await getDetail(ctx, row.hosp, row.service_id);
  } catch (e) {
    console.warn(`#${row.id} 燈號頁讀取失敗，改用號碼判斷：${e.message}`);
  }

  if (d && c.byCheckin) {
    const r = onDetail(row, d, true, cfg, ctx.now);
    if (r.handled) {
      // 報到順序模式：補上「改為依報到順序」提醒與讀取恢復
      const head = { update: { fail_count: 0, fail_alerted: 0 }, messages: [] };
      if (!row.by_checkin) {
        head.update.by_checkin = 1;
        head.messages.push(`ℹ️ ${title(row)}｜${CHECKIN_NOTE}`);
      }
      if (row.fail_alerted) head.messages.push(`✅ ${title(row)}｜恢復讀取`);
      return merge(head, r);
    }
    return merge(r, onReading(row, c.number, cfg, ctx.now, true));
  }

  const base = keepIfWaiting(onReading(row, c.number, cfg, ctx.now, c.byCheckin), row, d, cfg, ctx.now);
  if (!d || base.done) return base;
  const extra = onDetail(row, d, false, cfg, ctx.now);
  return { ...base, update: { ...extra.update, ...base.update }, messages: [...base.messages, ...extra.messages] };
}

/** 檢查一筆追蹤，更新資料庫，回傳要推播的訊息 */
async function checkOne(row, cfg, ctx) {
  const db = ctx.env.DB;
  if (!row.service_id || isExpired(row, cfg, ctx.now)) {
    await db.prepare("DELETE FROM trackings WHERE id = ?").bind(row.id).run();
    await logHistory({ ...ctx, chatId: row.chat_id }, [{ kind: "track", action: "end", ref_id: row.id,
      text: `${title(row)} ${row.my_number} 號（超過 ${cfg.maxHours} 小時自動移除）` }], { system: true });
    return [row.service_id
      ? `⏹ ${title(row)}｜已追蹤超過 ${cfg.maxHours} 小時，自動移除（最後燈號 ${row.last_number ?? "未知"}，你是 ${row.my_number} 號）`
      : `⏹ #${row.id}｜舊版追蹤資料，已移除，請重新追蹤`];
  }

  let result;
  try {
    const c = await findClinic(ctx, row.hosp, row.ampm, row.service_id);
    if (c?.fromDetail) c.byCheckin = !!row.by_checkin; // 燈號頁沒有這個標示：沿用上次列表的判斷
    result = c ? await evaluate(row, c, cfg, ctx) : onFailure(row, cfg, ctx.now, "列表中找不到這一診");
  } catch (e) {
    result = onFailure(row, cfg, ctx.now, e.message);
  }

  if (result.done) {
    await db.prepare("DELETE FROM trackings WHERE id = ?").bind(row.id).run();
    const why = result.messages.find((m) => /輪到|看診中|過號|不在候診/.test(m))?.match(/輪到了|看診中|已過號|過號|不在候診清單/)?.[0];
    await logHistory({ ...ctx, chatId: row.chat_id }, [{ kind: "track", action: "end", ref_id: row.id,
      text: `${title(row)} ${row.my_number} 號${why ? `（${why}）` : ""}` }], { system: true });
  } else {
    const keys = Object.keys(result.update);
    if (keys.length) {
      await db.prepare(`UPDATE trackings SET ${keys.map((k) => `${k} = ?`).join(", ")} WHERE id = ?`)
        .bind(...keys.map((k) => result.update[k]), row.id).run();
    }
  }
  return result.messages;
}

// 測試用
export const __menuCardForTest = (ctx) => menuCard(ctx);
export const __notesReplyForTest = (ctx, ...a) => notesReply(ctx, ...a);
